// マウスの座標保持用
let mouse_X = 0;
let mouse_Y = 0;

let dict_disp_flg = false;

//ページ数分子
let numerator = 1;

//  マウスの座標を常に取得
document.body.addEventListener("mousemove", function (event) {
    mouse_X = event.clientX;  //X座標
    mouse_Y = event.clientY;  //Y座標 
});



        const dict = chrome.runtime.getURL("./lib/kuromoji/dict");

        let data = "";

        //db用
        function getData(value) {
            return new Promise(resolve => {
                resolve(chrome.storage.local.get(value));
            })
        }

        //画面のどこかをクリックしたら開始
        document.body.onmousedown = function (event) {

            //マウスの情報取得
            let names = new Array();
            var x = event.clientX;
            var y = event.clientY;
            var element = document.elementFromPoint(x, y);//押した場所のHTMLタグを取得
            console.log({ x, y });


            //検索して見つかった単語と意味を二次元配列に格納
            /*
            let dictionary=[
                ["りんご","apple"],
                ["ぶどう","grape"],
                ["いちご","strawberry"],
                ["ロンドン自然史博物館","ロンドン自然史博物館（ロンドンしぜんしはくぶつかん、英: Natural History Museum）は、イギリスロンドンのサウス・ケンジントン（英語版）にある博物館。大英自然史博物館、英国自然史博物館などとも呼ばれ、自然史系博物館としてはイギリス最大であるのみならず、世界でもトップクラスである。"],
                ["あんず","apricot"],
                ["アボカド","avocado"],
                ["バナナ","banana"],
                ["さくらんぼ","cherry"],
                ["クランベリー","cranberry"],
                ["イチジク","fig"]
            ];
            */
            let dictionary = [];
            if (element.textContent != null && element.tagName !== "BODY" && element.tagName !== "DIV" && element.tagName !== "SPAN" && element.id !== "brainbookmark" && element.id !== "brainbookmark_meaning" && element.id !== "brainbookmark_back" && element.id !== "brainbookmark_meaning" && element.id !== "brainbookmark_page" && element.className !== "notitem" && element.id != 'brainbookmark_close' ) {//サイトの文字列を取得する条件式 //サイトの文字列を取得する条件式
                // if(element.tagName == "P" || element.tagName == "SPAN"){//Pタグの場合
                // element.id !== "brainbookmark_page_left" && element.id !== "brainbookmark_page_right"

                element.classList.add("color");
                var color = document.getElementsByClassName("color");
                color[0].style.backgroundColor = "#AAA";

                data = element.textContent;
                // Kuromoji解析にデータを渡す
                console.log(data);
                kuromoji.builder({ dicPath: dict }).build((err, tokenizer) => {
                    const tokens = tokenizer.tokenize(data);// 解析データの取得
                    for (i = 0; i < tokens.length; i++) {
                        names[i] = tokens[i].surface_form;//形態素したテキストを配列に代入
                    }

                    // console.log(names);
                    async function sample() {
                        result = await getData(names);//データベースに形態素配列を投げる
                        return result;
                    }

                    sample().then(result => {
                        // console.log(result);//見つかった答え
                        var ls = Object.keys(result);//取り出したオブジェクトからキーに入れる
                        for (j = 0; j < ls.length; j++) {//取れたキーの分だけ回す
                            console.log(ls[j] + " : " + result[[ls[j]][0]]);//オブジェクト＋キー指定で意味をとる
                            dictionary.push([ls[j], result[ls[j]][0]]);
                            console.log(dictionary);

                        }
                        // addCssLink();
                        disp(dictionary, element);
                        dict_disp_flg = true;

                    });

                    //色を消す
                    color[0].style.backgroundColor = null;
                    element.classList.remove("color");

                })
            } else if ( element.id !== "brainbookmark" && element.id !== "brainbookmark_meaning" && element.id !== "brainbookmark_back" && element.id !== "brainbookmark_meaning" && element.id !== "brainbookmark_close" && element.className !== "notitem") {
                console.log("Pタグじゃない");

                if (!dict_disp_flg) {
                    // face_analysisへ
                    const restartMessage = "restart"
                    window.postMessage(
                        { type: 'FROM_TEST', action: 'RESTART', restartMessage },
                        '*'
                    )
                }

            }
        }
        //-----表示部分-----------------------------------------------------------------------------------------------------------

        //辞書画面と詳細画面
        //↓の引数,elementを消したら治った
        function disp(dictionary,element) {
            console.log("disp呼び出し");
            /*
            #brainbookmark:div,表示画面
            #brainbookmark_close:span,閉じるボタン
            #brainbookmark_back:span,詳細画面->辞書画面ボタン
            #brainbookmark_ul:単語リスト
            .brainbookmark_li:単語リスト
            .brainbookmark_meaning:<p>,詳細画面遷移時のみ
            #brainbookmark_page:p,現在ページ数表示
            #brainbookmark_page_left:span,辞書画面ページ遷移ボタン
            #brainbookmark_page_right:span,辞書画面ページ遷移ボタン
            */
            let delete_element = document.getElementById("brainbookmark");

            // face_analysisへ
            const restartMessage = "stop"
            window.postMessage(
                { type: 'FROM_TEST', action: 'STOP', restartMessage },
                '*'
            )

            if (delete_element != null
                // && element.textContent != null 
                // && element.tagName !== "BODY" 
                // && element.tagName !== "DIV" 
                && element.id !== "brainbookmark"
                && element.id !== "brainbookmark_meaning"
                && element.id !== "brainbookmark_back"
                && element.id !== "brainbookmark_meaning"
                && element.id !== "brainbookmark_close"
                && element.className !== "notitem") {
                //辞書初期化を追加する予定
                delete_element.remove();
            }

            //div
            let new_div = document.createElement("div");
            new_div.id = "brainbookmark";
            //閉じるボタン
            let close_button = document.createElement("span");
            close_button.id = 'brainbookmark_close';
            new_div.appendChild(close_button);
            //ページ数分母(分子はnumerator(global))
            let denominator = Math.ceil(dictionary.length/4);
            console.log('dictionary.length'+dictionary.length);
            console.log('denominator'+denominator);
            //ページ数表示部分
            let page = document.createElement("p");
            page.id = 'brainbookmark_page';
            page.innerHTML = `${numerator}/${denominator}`;
            new_div.appendChild(page);
            //ページ切り替えボタン
            let left_button = document.createElement("span");
            left_button.id = 'brainbookmark_page_left';
            new_div.appendChild(left_button);
            let right_button = document.createElement("span");
            right_button.id = 'brainbookmark_page_right';
            new_div.appendChild(right_button);
            document.body.appendChild(new_div);

            //4つ区切り表示
            function add4li(numerator){
                //ページ遷移ボタン
                if(document.getElementById('brainbookmark_page_left') == null){
                    let left_button = document.createElement("span");
                    left_button.id = 'brainbookmark_page_left';
                    new_div.appendChild(left_button);
                }
                if(document.getElementById('brainbookmark_page_right') == null){
                    let right_button = document.createElement("span");
                    right_button.id = 'brainbookmark_page_right';
                    new_div.appendChild(right_button);
                }

                console.log('add4li');
                let index = (numerator-1)*4;
                //li追加
                new_div.innerHTML += "<ul id='brainbookmark_ul' class='notitem'></ul>";
                document.body.appendChild(new_div);
                let ul = document.getElementById("brainbookmark_ul");
                for(let i=index;i<Math.min(index+4,dictionary.length,);i++){
                    ul.innerHTML+=`<li class='brainbookmark_li'><p class='notitem'>${dictionary[i][0]}</p></li>`;
                }
                //ページ
                let page = document.getElementById("brainbookmark_page");
                page.innerHTML = `${numerator}/${denominator}`;
                //クリックイベントの設定
                for(let i=index;i<Math.min(index+4,dictionary.length);i++){
                    let word = document.querySelectorAll(".brainbookmark_li");
                    word[i%4].addEventListener("click",function(){
                        //ul,li消去
                        let ul = document.getElementById("brainbookmark_ul");
                        let li = document.getElementsByClassName("brainbookmark_li");
                        for(let i=index;i<Math.min(index+4,dictionary.length,);i++){
                            let e = li[0];
                            e.parentNode.removeChild(e);
                        }
                        ul.remove();
                        //ページ数表示消去
                        let page = document.getElementById("brainbookmark_page");
                        page.remove();
                        //left,right消去
                        let left = document.getElementById("brainbookmark_page_left");
                        let right = document.getElementById("brainbookmark_page_right");
                        if(left !== null) left.remove();
                        if(right !== null)right.remove();
                        //<p class="brainbookmark_meaning">の追加
                        let meaning = document.createElement("p");
                        meaning.id = 'brainbookmark_meaning';
                        meaning.innerHTML = `${dictionary[i][1]}`;
                        let div_element = document.getElementById("brainbookmark");
                        div_element.appendChild(meaning);
                        //戻るボタンの追加
                        let back_button = document.createElement("span");
                        back_button.id = 'brainbookmark_back';
                        new_div.appendChild(back_button);

                        //戻るボタンクリック:詳細画面->辞書画面
                        let back_button_click = document.getElementById("brainbookmark_back");
                        back_button_click.addEventListener("click", function () {
                            if (document.getElementById("brainbookmark_meaning") != null) {
                                let element = document.getElementById("brainbookmark_meaning");
                                element.remove();
                                console.log("戻る呼び出し");
                                console.log(dictionary);
                            /*
                            if (document.getElementById("brainbookmark") != null) {
                                let element = document.getElementById("brainbookmark");
                                element.remove();
                            }
                            */
                            //ページ
                            let page = document.createElement("p");
                            page.id = 'brainbookmark_page';
                            new_div.appendChild(page);
                            //矢印
                            let left_button = document.createElement("span");
                            left_button.id = 'brainbookmark_page_left';
                            new_div.appendChild(left_button);
                            let right_button = document.createElement("span");
                            right_button.id = 'brainbookmark_page_right';
                            new_div.appendChild(right_button);
                            add4li(numerator);
                            //戻るボタン消去
                            let remo = document.getElementById('brainbookmark_back');
                            remo.remove();
                            }
                        })
                })
                }
                //ページ遷移ボタン:left
                let page_left_click = document.getElementById("brainbookmark_page_left");
                page_left_click.addEventListener("click",function(){
                console.log("left clicked");
                if(numerator>1){
                    //既存のul,liを消す
                    let ul = document.getElementById("brainbookmark_ul");
                    let li = document.getElementsByClassName("brainbookmark_li");
                    while(li.firstChild){
                        li.removeChild(li.firstChild);
                        }
                        ul.remove();
                        //add4liを呼ぶ
                        numerator--;
                        console.log("numerator:"+numerator);
                        add4li(numerator);
                        //disp(dictionary,element);
                    }})
                //right
                let page_right_click = document.getElementById("brainbookmark_page_right");
                page_right_click.addEventListener("click",function(){
                console.log("right click");
                if(numerator<denominator){
                    //既存のul,liを消す
                    let ul = document.getElementById("brainbookmark_ul");
                    let li = document.getElementsByClassName("brainbookmark_li");
                    while(li.firstChild){
                        li.removeChild(li.firstChild);
                    }
                    ul.remove();
                    //add4liを呼ぶ
                    numerator++;
                    console.log("numerator:"+numerator);
                    add4li(numerator);
                    //disp(dictionary,element);
                }})
                //表示ページによってページ遷移ボタンを非表示
                if(numerator == 1){
                    let remove_page_left = document.getElementById("brainbookmark_page_left");
                    remove_page_left.remove();
                }
                if(numerator == denominator){
                    let remove_page_right = document.getElementById("brainbookmark_page_right");
                    remove_page_right.remove();
                }
                //閉じる
                let close_button_click = document.getElementById("brainbookmark_close");
                close_button_click.addEventListener("click", function () {
                    console.log("閉じる呼び出し");
                    //辞書初期化を追加する予定
                    let element = document.getElementById("brainbookmark");
                    element.remove();
                    //ページ数分子初期化
                    numerator = 1;
                    dict_disp_flg = false;
                    // face_analysisへ
                    const restartMessage = "restart"
                    window.postMessage(
                        { type: 'FROM_TEST', action: 'RESTART', restartMessage },
                        '*'
                    )
                    // content.jsへ
                    const imgtMessage = "img"
                    window.postMessage(
                        { type: 'FROM_TEST', action: 'RESET', imgtMessage },
                        '*'
                    )
                })
            }
            //辞書画面html生成
            if(dictionary.length!=0){
                console.log("html生成");
                add4li(numerator);
            }else{
                //検索したが単語が登録されていなかった場合
                new_div.innerHTML += "<p id='brainbookmark_notfound' class='notitem'>見つからなかったよ</p>";
                //ページ数表示消去
                let page = document.getElementById("brainbookmark_page");
                page.remove();
                //left,right消去
                let left = document.getElementById("brainbookmark_page_left");
                let right = document.getElementById("brainbookmark_page_right");
                left.remove();
                right.remove();
                document.body.appendChild(new_div);
                //閉じる
                let close_button_click = document.getElementById("brainbookmark_close");
                close_button_click.addEventListener("click", function () {
                    console.log("閉じる呼び出し");
    
                    //辞書初期化を追加する予定
                    let element = document.getElementById("brainbookmark");
                    element.remove();
                    //ページ数分子初期化
                    numerator = 1;
                    dict_disp_flg = false;
                    // face_analysisへ
                    const restartMessage = "restart"
                    window.postMessage(
                        { type: 'FROM_TEST', action: 'RESTART', restartMessage },
                        '*'
                    )
    
                    // content.jsへ
                    const imgtMessage = "img"
                    window.postMessage(
                        { type: 'FROM_TEST', action: 'RESET', imgtMessage },
                        '*'
                    )
                })

            }

            //-----------------↓クリック類----------------------//

            /*
            //閉じるボタンクリック:#brainbookmarkの削除,dictionaryの初期化,顔認識処理の再開(?)
            let close_button_click = document.getElementById("brainbookmark_close");
            close_button_click.addEventListener("click", function () {
                console.log("閉じる呼び出し");

                //辞書初期化を追加する予定
                let element = document.getElementById("brainbookmark");
                element.remove();
                //ページ数分子初期化
                numerator = 1;
                dict_disp_flg = false;
                // face_analysisへ
                const restartMessage = "restart"
                window.postMessage(
                    { type: 'FROM_TEST', action: 'RESTART', restartMessage },
                    '*'
                )

                // content.jsへ
                const imgtMessage = "img"
                window.postMessage(
                    { type: 'FROM_TEST', action: 'RESET', imgtMessage },
                    '*'
                )
            })
            */


        }


        function addCssLink() {
            //※manifest.jsonの web_accessible_resources にbrainbookmark.cssを追加すること
            let head = document.getElementsByTagName('head').item(0);
            let link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = chrome.runtime.getURL('./css/brainbookmark.css');
            link.type = 'text/css';
            head.appendChild(link);
        }

        //--------------------------------------------------------------------------------------------//


window.addEventListener('message', (event) => {
    const eventType = event.data.type;
    console.log({ eventType });
    if (event.data.type && event.data.type === 'FROM_FACE_ANALYSIS') {
        const temp = event.data;
        console.log({ temp });
        switch (event.data.action) {
            case "SEND_TEST":
        console.log("clickイベント強制発火");
        // clickイベント作成（マウスのある座標で）
        let e = new MouseEvent("mousedown", { clientX: mouse_X, clientY: mouse_Y });
        // clickイベントの強制発火
        document.body.dispatchEvent(e);
                break;
        }

    }

}, false)


