//chrome.storage確認用js

// chrome storageクリア
// chrome.storage.local.clear();

var bom = document.getElementById("bom");

function getData(value){
    return new Promise(resolve =>{
        resolve(chrome.storage.local.get(value));
    }) 
}

bom.addEventListener('click', () =>{
  async function sample() {
    result = await getData(null);
    return result;
    }

  sample().then(result =>{
    console.log(result);
    // var ls = Object.keys(result);
    // console.log(ls);
    // console.log(result[ls[0]]);
    });
});


