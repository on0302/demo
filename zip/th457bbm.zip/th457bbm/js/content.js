let headCSS = document.getElementsByTagName('head').item(0);
let link = document.createElement('link');
link.rel = 'stylesheet';
// link.href = chrome.runtime.getURL('./css/video.css');
link.href = chrome.runtime.getURL('./css/brainbookmark.css');
link.type = 'text/css';
headCSS.appendChild(link);
//直接スクリプトを埋め込む

// modelsへのパス（拡張機能内での）をface_analysis.jsへ渡すため保存 
localStorage.saveKey = chrome.runtime.getURL('../models');

// headとbodyにそれぞれ入れる
const head = document.head
const body = document.body

// chrome storage(ローカル) から取り出し
// chrome.storage.local.get(null, function(result) {
//   console.log({result});
// }); 

// headへ書き込み終わってからbodyへ
let promise = new Promise((resolve, reject) => {
  script_inject(head, chrome.runtime.getURL('../lib/face-api/face-api.min.js'));
  resolve(chrome.runtime.getURL('./js/face_analysis.js'));
  reject("失敗");
}).then(
  (path) => { script_inject(body, path); }, // 成功時の処理
  (e) => { console.log(e); } // 失敗時の処理 
);

function script_inject(element, path) {
  const script = document.createElement('script');
  script.src = path;
  element.appendChild(script);
}

//-----------------------------------//
// function getData(value){
//   return new Promise(resolve =>{
//       resolve(chrome.storage.local.get(value));
//   }) 
// }



// async function sample() {
//   result = await getData(null);
//   return result;
//   }

// sample().then(result =>{
//   console.log(result);
//   // var ls = Object.keys(result);
//   // console.log(ls);
//   // console.log(result[ls[0]]);
//   });


// --- ロード開始 ---//
const imgTag = document.createElement("img");
imgTag.setAttribute("id", "floating_gif");

// readyStateがcomplete（＝最初のHTML文書の読み込みと解析が完了）になったら開始
document.onreadystatechange = function () {
  if (document.readyState === 'complete') {
    console.log("DOMContentLoaded");
    // path指定
    imgTag.src = chrome.runtime.getURL("../images/loading2.gif");
    body.appendChild(imgTag);

    // 画像設定
    // setFloatingImage(chrome.runtime.getURL("../images/loading2.gif"), imgTag, 300, 250, "-4%", "-6%");
  }
}

// CSSファイルでやる場合はpath指定だけ残せばOK
// function setFloatingImage(path, element, width, height, bottom, right) { // bottom,rightは文字列で指定(0以外)
//   // path指定
//   element.src = path;
//   // サイズ指定
//   element.width = width;
//   element.height = height;
//   // 右下に固定
//   element.style.position = "fixed";
//   element.style.bottom = bottom;
//   element.style.right = right;
//   element.style.zIndex = 9999;

//   body.appendChild(element);
// }

window.addEventListener('message', (event) => {
  // const eventType = event.data.type;
  // console.log({ eventType });

  if ((event.data.type && event.data.type === 'FROM_FACE_ANALYSIS' || event.data.type === 'FROM_TEST')
    && (event.data.action ==='LOADED' || event.data.action ==='RESET' || event.data.action ==='STOP')){

    // 前のgifがあったら消す
    if (document.getElementById("floating_gif") != null) {
      body.removeChild(imgTag);
    }

    switch (event.data.action) {
      case 'LOADED': // ランドマーク描画完了
      case 'NO_CAMERA': // カメラがサポートされていない場合
      case 'RESET': // 辞書が閉じられたら
        // 待機画像設定
        imgTag.src = chrome.runtime.getURL("../images/gimon2.gif");
        body.appendChild(imgTag);
        // setFloatingImage(chrome.runtime.getURL("../images/gimon2.gif"), imgTag, 300, 250, "-4%", "-6%");
        break;

      // 悩んでる判定になったら 
      // 辞書と被っていると閉じるボタンが押せないけど、ブラウザの幅をスライドして画像と辞書をずらせば押せる
      case 'STOP':
        // 辞書表示中画像設定
        imgTag.src = chrome.runtime.getURL("../images/teach.gif");
        body.appendChild(imgTag);
        break;
    }
  }

  // // --- face_analysisからtestへ送られるタイミングで 
  // if (event.data.type && event.data.type === 'FROM_EMBED') {
  //   // 切り替え

  //   // 待機画像設定
  // }

}, false);
