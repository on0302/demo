//chrome.storage/optionページ入力機能

const btn = document.getElementById("btn");
const ocdData = document.getElementById("result");
const word = document.getElementById("word");
const meaning = document.getElementById("meaning");
let result;


//登録されているデータを取得
function getData(value,value2){
    return new Promise(resolve =>{
        resolve(chrome.storage.local.get(value));
    }) 
}

//Clickイベント
btn.addEventListener('click', function(){
    console.log('clicked');

    //inputから引っ張て来たデータ
    let wordData = word.value;
    let meaningData = meaning.value;

    //両方入力されていたら処理が走る
    if(wordData && meaningData){
        //ローカルストレージへタイトルと中身を挿入
        chrome.storage.local.set({ [wordData] : [meaningData] }, function () { 
            async function sample() {
                result = await getData(wordData);
                return result;
            }
            
            sample().then(result =>{
                //Keyを取得
                var ls = Object.keys(result);
                console.log(ls);
                console.log(result[ls[0]]);
                ocdData.innerText = "タイトル:"+ ls +"内容："+result[ls[0]]+"を登録";
            });

            console.log("set:"+wordData);
            console.log("↓ chrome storage(しばらく待機) ↓");
            console.log("result:"+result[ls[0]]);
        });
    }else{
        console.log("not:"+wordData);
    }

});

