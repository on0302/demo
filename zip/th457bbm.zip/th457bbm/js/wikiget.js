var url = location.href;
var title = "https://ja.wikipedia.org/wiki/";
console.log(url);

var regexp = new RegExp(title,'g'); 
var result = url.match(regexp);

if(!result || result === null){
    console.log("not match");
}else{
    //h1オブジェクト取得
    var top_heading = document.getElementsByClassName("mw-page-title-main");
    top_heading = top_heading[0].textContent; //text取得
    console.log(top_heading);

    //pタグ(概要)の親要素を取得
    var box = document.querySelector(".mw-parser-output");
    console.log(box);
    var wiki_content = box.querySelector('p').textContent; //pタグのテキスト取得
    console.log(wiki_content);
  
    if(top_heading && wiki_content){
        chrome.storage.local.set({ [top_heading] : [wiki_content] }, function () { 
            console.log("done");
        }); 
    }
}

