importScripts("../lib/face-api/face-api.min.js");

console.log("service worker");

chrome.contentSettings.camera.set({
  primaryPattern: chrome.runtime.getURL('/*').replace(/^.*?:\/\//, '*://'),
  setting: chrome.contentSettings.CameraContentSetting.ALLOW, // 'allow' という文字列
  scope: 'regular'
})


chrome.runtime.onInstalled.addListener(function() {
 
  fetch("database.json")
  .then(response => response.json())
  .then(data =>{
      // console.log(data.length);
      for(i = 0; i < data.length; i++){
          var key = Object.keys(data[i]);
          var content = data[i][key].info;
          console.log(key + " : " + content);
  
          chrome.storage.local.set({ [key] : [content] }, function () { 
           
          }); 
          
      };
  });

});