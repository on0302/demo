const func = () => {
    let isLoaded = false;

    // mediaDevicesがある＆getUserMediaがある→サポートされている
    if (
        "mediaDevices" in navigator &&
        "getUserMedia" in navigator.mediaDevices
    ) {
        // 挿入 : 一番上のdivのstyleでサイズ、位置指定(width, height, top, left)
        let body_element = document.body;
        body_element.insertAdjacentHTML(
            "afterbegin",
            '<div class="video_canvas_container"><div class="relative_container"><div class="box-border box-border-leftTop"></div><div class="box-border box-border-leftBottom"></div><div class="box-border box-border-rightTop"></div><div class="box-border box-border-rightBottom"></div><video id="video" muted autoplay></video><canvas id="facecanvas"></canvas></div></div>'
        );

        // ビデオをドラッグできるようにする
        const position = { x: 0, y: 0 };
        var script = document.createElement("script");
        // interact.jsを読み込ませる
        script.setAttribute(
            "src",
            "https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js"
        );
        script.setAttribute("type", "text/javascript");
        
        // interact.jsを読み込んだらドラッグできるようにする
        var w = document.documentElement;
        console.log({w});
        script.addEventListener("load", function () {
            interact(".video_canvas_container")
                // ドラッグ
                .draggable({
                    onmove: window.dragMoveListener,
                    listeners: {
                        start(event) {
                            console.log(event.type, event.target);
                        },
                        move(event) {
                            position.x += event.dx;
                            position.y += event.dy;

                            event.target.style.transform = `translate(${position.x}px, ${position.y}px)`;
                        },
                    },
                    // 動かせる範囲を限定(範囲外にドラッグしても戻ってくる)
                    modifiers: [
                        interact.modifiers.restrict({
                          // 親要素（ブラウザの表示領域内）
                          restriction: 'parent',
                          endOnly: true
                        })
                      ],
                })
                // リサイズ
                .resizable({
                    modifiers: [
                        interact.modifiers.restrictSize({
                            // videoの最大値、最小値を設定
                            min: { width: 100, height: 100 },
                            max: { width: 500, height: 500 }
                        }),
                        interact.modifiers.aspectRatio({
                            // 親要素の比率に準ずるようにする
                            ratio: 'preserve',
                            modifiers: [
                                interact.modifiers.restrictEdges({ 
                                    outer: 'parent',
                                    endOnly: true, 
                                })
                            ]
                        })
                    ],
                    // 画面の縦横どこからでもリサイズできるようにする
                    edges: { left: true, right: true, bottom: true, top: true },
                })
                // リサイズ計算
                .on('resizemove', function (event) {
                    var target = event.target;

                    // video_canvas_containerのwidth,heightを変更
                    target.style.width = event.rect.width + 'px';
                    target.style.height = event.rect.height + 'px';
                });
        });
        document.head.appendChild(script);

        // canvasはデモ用
        const canvas = document.getElementById("facecanvas");
        const videoEl = document.getElementById("video");
        console.log({ canvas, videoEl });
        const inputSize = 224; // GPUのメモリ使用量に関系している
        const scoreThreshold = 0.5; // スコアの閾値
        let repeat;
        let repeatFlg = true;

        // videoのメタデータが読み込まれたら実行
        videoEl.addEventListener("loadedmetadata", (event) => {
            // console.log("loadedmetadata");
            onPlay();
        });

        async function onPlay() {
            if (
                videoEl.paused || // true: 一時停止
                videoEl.ended || // 再生やストリーミングが終了
                !faceapi.nets.tinyFaceDetector.params  // 恐らくfaceapiが読み込まれていない状態
            ) {
                console.log("return");
                return repeat = setTimeout(() => onPlay()) ;
            }

            // 停止
            if (!repeatFlg) return;

            // メモリ使用量、閾値をオプションとして指定
            const options = new faceapi.TinyFaceDetectorOptions({
                inputSize,
                scoreThreshold,
            });

            // 顔認識、ランドマーク設置、感情検出の結果を受け取る
            const result = await faceapi
                .detectSingleFace(videoEl, options) // 顔認識
                .withFaceLandmarks() // ランドマーク
                .withFaceExpressions(); // 感情検出

                let angleFlg = false;
            // 顔認識、表情検出できたら
            if (result) {
                // 以下4行デモ用
                const dims = faceapi.matchDimensions(canvas, videoEl, true); // canvasと動画のサイズ合わせ
                const minProbability = 0.05; // 最小値
                const resizedResult = faceapi.resizeResults(result, dims); // canvas&動画と解析結果（ランドマークや表情）のサイズ合わせ
                // 認識した顔を囲う枠を描画
                faceapi.draw.drawDetections(canvas, resizedResult);
                // その顔にランドマークを描画
                faceapi.draw.drawFaceLandmarks(canvas, resizedResult);
                // その枠に検出した感情を表示
                faceapi.draw.drawFaceExpressions(
                    canvas,
                    resizedResult,
                    minProbability
                );

                // true : ランドマーク描画済, false : ランドマーク未描画
                if (!isLoaded) {
                    isLoaded = true;
                    console.log("ランドマーク描写");
                    const message = "drawFaceLandmarks";
                    window.postMessage(
                        {
                            type: "FROM_FACE_ANALYSIS",
                            action: "LOADED",
                            message,
                        },
                        "*"
                    );
                }

                // 鼻の座標を取得（Dlib Face Landmark 68データのポイント28~36が取れる）
                const landmarks = result.landmarks;
                const nose = landmarks.getNose();
                console.log({ nose });
                // 傾き計算
                resultAngle = getAngle(
                    nose[6]._x,
                    nose[6]._y,
                    nose[0]._x,
                    nose[0]._y
                );
                console.log("rad:" + resultAngle);

                let angry = result.expressions.angry;
                // 左右に15度(暫定)づつ以上傾いた場合に表示(自身の顔を左：角度＋,右：角度-) + 眉間にしわを寄せる(=怒りの表情と似通っている)
                if (105 <= resultAngle || resultAngle <= 75 || result.expressions.angry > 0.2) {
                    // setTimeout中断
                    clearTimeout(repeat);
                    angleFlg = true;
                }
            }

            if (!angleFlg) {
                // setTimeoutが中断されてない場合はループ
                repeat = setTimeout(() => onPlay());
            } else {
                // 傾いた判定なのでここでマウス関連
                console.log("悩んでいますか?");

                // const data = window.document
                const data = "test";

                // const data = JSON.stringify(window);
                // console.log({ data });
                window.postMessage(
                    { type: "FROM_FACE_ANALYSIS", action: "SEND_TEST", data },
                    "*"
                );
            }
        }

        // 傾き計算
        function getAngle(x1, y1, x2, y2) {
            // 鼻（眉間：鼻のはじまり）の座標 – 鼻（の頂点：穴の間の突起部分）の座標とすることで
            // 鼻（の頂点：穴の間の突起部分）を原点(0, 0)へ移動
            let rad = Math.atan2(Math.abs(y2 - y1), x2 - x1);
            // 単位がラジアンで返ってくるので度に変換
            return (rad * 180) / Math.PI;
        }

        async function run() {
            // console.log("run");
            // modelsへのパス取り出し
            var models_path = localStorage.saveKey;
            localStorage.clear();
            // console.log(models_path);

            // modelをそれぞれロード
            await faceapi.nets.tinyFaceDetector.load(models_path); // 顔認識
            await faceapi.loadFaceLandmarkModel(models_path); // ランドマーク(目や鼻の位置など顔の特徴を抽出する上で重要なキーポイント、特徴点)
            await faceapi.nets.faceExpressionNet.load(models_path); // 感情検出("neutral","happy","sad","angry","fearful","disgusted","surprised")

            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    video: {},
                });
                // console.log(tream });
                videoEl.srcObject = stream;
            } catch (error) {
                console.log("許可なし: " + error);
            }
        }

        // console.log({ document, videoEl, })
        // console.log(document.readyState);

        // readyStateがcomplete（＝最初のHTML文書の読み込みと解析が完了）になったら開始
        document.onreadystatechange = function () {
            if (document.readyState === "complete") {
                // console.log("DOMContentLoaded");
                run();
            }
        };

        window.addEventListener(
            "message",
            (event) => {
                const eventType = event.data.type;
                console.log({ eventType });
                if (event.data.type && event.data.type === "FROM_TEST") {
                    const temp = event.data.data;
                    console.log({ temp });
                    switch (event.data.action) {
                        case "RESTART":
                            repeatFlg = true;
                            repeat = setTimeout(() => onPlay());
                            console.log("restart:" + repeatFlg);
                            break;
                        case "STOP":
                            repeatFlg = false;
                            clearTimeout(repeat);
                            console.log("stop:" + repeatFlg);
                            break;
                    }
                }
            },
            false
        );
    } else {
        console.log("カメラがサポートされてない");
        window.postMessage(
            { type: "FROM_FACE_ANALYSIS", action: "NO_CAMERA", message:"no_camera" },
            "*"
        );
    }
};
func();
